from pathlib import Path
import hashlib,json,sys
root=Path(sys.argv[1] if len(sys.argv)>1 else '.').resolve()
out=root/'release'/'MANIFEST.json'
ignore={'.git','__pycache__','.pytest_cache','target'}
def included(p):
    rel=p.relative_to(root)
    return (p.is_file() and p.resolve()!=out.resolve() and p.name!='MANIFEST.json' and not p.name.startswith('._')
            and not (rel.parts and rel.parts[0] in {'.claude', '.superpowers'})
            and rel.as_posix() != 'CLAUDE.md'
            and rel.as_posix() != 'release/RC10-CANDIDATE-PACKAGE.zip'
            and not any(x in ignore for x in rel.parts)
            and not ('.mvn' in rel.parts and any(x.startswith('apache-maven-') for x in rel.parts)))
entries=[]
for p in sorted(root.rglob('*')):
    if included(p):
        b=p.read_bytes(); entries.append({'path':p.relative_to(root).as_posix(),'sha256':hashlib.sha256(b).hexdigest(),'size':len(b)})
out.parent.mkdir(parents=True,exist_ok=True)
out.write_text(json.dumps({'manifest_version':'0.4.8.3','files':entries},indent=2)+'\n')
print(f'wrote {out}: {len(entries)} files')
