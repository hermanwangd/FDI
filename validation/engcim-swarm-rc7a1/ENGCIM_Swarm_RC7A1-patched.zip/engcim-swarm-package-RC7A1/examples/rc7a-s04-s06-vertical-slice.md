# RC7-A Regression — S04→S06 Vertical Slice

Goal: prove that a blocking PM decision can pause and resume the same mission, then allow S05 and S06 to complete.

Required sequence:
1. S04 produces Intention Spec r1 with `implementationAuthorized=false`.
2. S04 creates a QuestionSet with two blocking questions.
3. Mission enters `WAITING_FOR_INPUT`.
4. Human submits DecisionResponse.
5. Same S04 Mission resumes with a new Run.
6. S04 produces Intention Spec r2 with `implementationAuthorized=true`.
7. S05 creates Development Result.
8. S06 reproduces FV-003, fixes it, retests, and produces Verification Result PASS.


## RC7-A.1 additions

- After every state mutation, create a state snapshot and upload it as a durable attachment.
- Parent issue metadata must contain only `swarm.stateRef`, `swarm.stateRevision`, and `swarm.summaryStatus`.
- Every state mutation must pass `--expected-revision`.
- Duplicate human comments / duplicate wake events must produce `NO_OP`, not duplicate resume.
- S05 must run `software-development/scripts/authorization_gate.py` before branch or code edits.
