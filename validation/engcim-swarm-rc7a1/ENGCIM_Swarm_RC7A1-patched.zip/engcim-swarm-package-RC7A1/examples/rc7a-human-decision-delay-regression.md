# RC7-A Human Decision Delay Regression

Procedure:
1. Run S04 until `WAITING_FOR_INPUT`.
2. Wait for a delay window.
3. Submit DecisionResponse.
4. Resume the same mission.
5. Verify no duplicate mission, no lost QuestionSet, no stale review reuse, and monotonic stateRevision.
