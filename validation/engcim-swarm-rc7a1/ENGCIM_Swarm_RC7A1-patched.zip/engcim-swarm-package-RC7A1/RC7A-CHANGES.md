# RC7-A Changes — Human Input / Resume Vertical Slice

RC7-A is based on RC6 and limits scope to the first complete Software Delivery vertical slice.

## Goal

```text
S04 PM Intention
→ WAITING_FOR_INPUT
→ Human DecisionResponse
→ Resume same Mission
→ Intention Spec revision N+1
→ S05 Software Development
→ Development Result
→ S06 Verification
→ FV-003 reproduce
→ fix
→ fresh retest
→ Verification Result PASS
```

## Added

- `human-input-resume` skill
- `QuestionSet`
- `DecisionResponse`
- `MissionResumeEvent`
- compact `MissionExecutionState`
- `swarm.stateRef / swarm.stateRevision / swarm.summaryStatus`
- S04→S06 vertical-slice regression
- human decision delay regression

## Non-goals

No MCP change, Product Context redesign, Graphify change, S07–S10 expansion, DB/event-store service.
