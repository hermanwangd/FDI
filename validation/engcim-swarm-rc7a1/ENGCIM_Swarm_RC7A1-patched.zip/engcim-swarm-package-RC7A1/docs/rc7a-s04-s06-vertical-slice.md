# RC7-A S04→S06 Vertical Slice

## Objective

Complete one real Software Delivery path from PM ambiguity to verified change.

## Required path

```text
S04 → Intention Spec r1 → QuestionSet → WAITING_FOR_INPUT
Human → DecisionResponse
S04 resume → Intention Spec r2 → implementationAuthorized=true
S05 → Development Result
S06 → FV-003 reproduced → root cause → fix → fresh retest → Verification Result PASS
```

## Expected human decisions for existing fixture

```yaml
answers:
  - questionId: Q-interaction-target
    answer: "Opening a valid chart should require one primary user action from the Chart Viewer entry point."
  - questionId: Q-retry-404
    answer: "404 chart-not-found responses are not retryable; surface a recoverable user error without retrying."
```

## Acceptance

Same missionRef before/after human input; QuestionSet and DecisionResponse are artifacts; only compact Multica metadata is required; stale review/verification state is not reused; S05 starts only after DecisionResponse; S06 verifies the fixed current revision.
