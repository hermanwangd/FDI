# RC7-A.1 Human Comment Resume Flow

## Why

RC6 proved that S04 correctly blocked when PM decisions were missing. RC7-A.1 makes that block recoverable.

## Flow

1. Product Manager Agent creates:
   - `QuestionSet.yaml`
   - `QuestionSet.md`

2. Orchestrator posts `QuestionSet.md` to the parent issue and attaches `QuestionSet.yaml`.

3. Orchestrator records MissionExecutionState:
   - `summaryStatus=WAITING_FOR_INPUT`
   - `pendingInputs[]` contains `questionSetRef`
   - durable `stateRef` points to the uploaded state snapshot.

4. Human PM replies in the same parent issue using a normal comment.

5. Leader wakes from the human comment and creates:
   - `DecisionResponse.yaml`
   - `MissionResumeEvent.yaml`

6. Leader applies `resume` with `--expected-revision`.

7. Same mission resumes; a new run produces Intention Spec r2.

## Human-friendly QuestionSet

The Markdown must not ask PM to edit YAML.

Example:

```markdown
# PM Decision Required

Mission: S04 Chart Viewer Enhancement

## Q1 — Interaction reduction target
What measurable interaction-reduction target defines success?

Please answer one of:
- one primary action
- two primary actions
- other: <describe>

## Q2 — 404 retry semantics
Should chart-not-found 404 responses be retryable?

Please answer one of:
- non-retryable user error
- retryable transient failure
```

The agent converts the human reply to `DecisionResponse.yaml`.
