# RC7-A Workflow Contract

## Lifecycle

```text
RUNNING
  ↓ blocking ambiguity
WAITING_FOR_INPUT
  ↓ DecisionResponse
RUNNING
  ↓ final artifact
IN_REVIEW
```

`WAITING_FOR_INPUT` is ENGCIM mission state, not just a Multica issue status.

## Artifacts

### QuestionSet

A structured request for a human decision.

Required fields:
`questionSetRef`, `missionRef`, `sourceArtifactRef`, `sourceArtifactRevision`, `requestedRole`, `blocking`, `questions[]`, `evidenceRefs[]`.

### DecisionResponse

The human answer to a QuestionSet.

Required fields:
`decisionRef`, `questionSetRef`, `missionRef`, `decidedBy`, `answers[]`, `evidenceRefs[]`.

### MissionResumeEvent

The event that resumes the same mission.

Required fields:
`eventRef`, `eventType`, `missionRef`, `questionSetRef`, `decisionRef`, `resumeFromRunRef`, `newRunRef`, `stateRef`, `stateRevisionBefore`, `stateRevisionAfter`.

## Same mission, new run

Correct:

```text
Mission M-2051
  Run R1 → WAITING_FOR_INPUT
  DecisionResponse D1
  Run R2 → resume M-2051
```

Wrong:

```text
Mission M-2051 blocked
Mission M-2052 restarted with answer
```

## Compact stateRef

Avoid one metadata key per child/review/verification field. Store only:

```text
swarm.stateRef
swarm.stateRevision
swarm.summaryStatus
```

State body:

```text
.swarm/missions/<missionRef>/state.json
```

## Staleness

A `DecisionResponse` changes the input artifact set. Reviews/verifications attached to prior artifact revisions are stale. The resumed run must produce a new Intention Spec revision before authorizing S05.
