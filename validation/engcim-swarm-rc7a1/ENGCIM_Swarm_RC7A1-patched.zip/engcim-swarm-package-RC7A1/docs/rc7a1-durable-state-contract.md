# RC7-A.1 Durable State Contract

## Principle

`MissionExecutionState` is the only ENGCIM execution truth.

Multica issue metadata is a projection/pointer only:

```text
swarm.stateRef
swarm.stateRevision
swarm.summaryStatus
```

Do not store execution state as individual issue metadata keys such as:

```text
swarm.child.A.reviewVerdict
swarm.child.A.verificationRevision
swarm.review.*
swarm.verification.*
```

## Durable stateRef

`stateRef` must be durable across:
- delayed human answer;
- daemon restart;
- fresh task workdir;
- run retry.

Preferred MVP representation:

```text
attachment:<attachment-id>
```

where the attachment is a JSON snapshot:

```text
mission-state-r<N>.json
```

Local file state is allowed only for package-local self-test:

```text
file://...
durability: local-test
```

## State snapshot lifecycle

```text
state r1
→ mission-state-r1.json
→ upload as attachment
→ metadata swarm.stateRef=attachment:<id>, stateRevision=1

state r2
→ mission-state-r2.json
→ upload as attachment
→ metadata stateRef=attachment:<id2>, stateRevision=2
```

Each revision is immutable. Do not edit prior state snapshots.

## CAS

Every mutation must provide:

```text
--expected-revision <N>
```

If current revision differs:

```text
STALE_STATE
```

No mutation is applied.

## Idempotency

Repeated processing of the same input must be safe:

| Input | Duplicate behavior |
|---|---|
| QuestionSet | NO_OP if already pending/answered |
| DecisionResponse | NO_OP if already consumed |
| ResumeEvent | NO_OP if already applied |
| Artifact revision | NO_OP if same artifact/revision already recorded |

## Human resume flow

```text
QuestionSet.yaml + QuestionSet.md
  ↓ posted to parent issue
MissionExecutionState WAITING_FOR_INPUT
  ↓ human issue comment
Leader wakes
  ↓ DecisionResponse.yaml
  ↓ MissionResumeEvent.yaml
Same mission resumes with new run
```

The human comment is evidence. The DecisionResponse is the machine artifact.
