# RC7-A.1 Changes — Durable Human Resume Runtime Correction

RC7-A.1 is an architecture correction over RC7-A. It does not expand Scenario scope.

## Fixed P0 issues

1. **MissionExecutionState is the only ENGCIM execution truth.**
   - Do not write `swarm.child.*`, `swarm.review.*`, or `swarm.verification.*` issue metadata.
   - Multica metadata projection is limited to:
     - `swarm.stateRef`
     - `swarm.stateRevision`
     - `swarm.summaryStatus`

2. **Durable stateRef.**
   - `stateRef` must identify a durable artifact/attachment, not only a run-local file path.
   - Local file paths are allowed only for package-local self-test and must be marked `durability: local-test`.

3. **Authorization Gate.**
   - Intention Spec now has `implementationAuthorization`.
   - S05 must stop unless `implementationAuthorization.authorized=true`.

4. **Human comment resume flow.**
   - QuestionSet is posted as human-readable Markdown plus machine-readable YAML.
   - Human response comes through a normal parent issue comment.
   - Leader wakes, creates DecisionResponse, creates MissionResumeEvent, and resumes the same Mission.

5. **CAS and idempotency.**
   - Mutating state commands require `--expected-revision`.
   - Duplicate QuestionSet, DecisionResponse, ResumeEvent, and artifact revision become safe `NO_OP`.

6. **RC6 validation patch carry-forward.**
   - RC7-A.1 keeps the RC6/RC7-A role-binding parser requirement and verification heredoc patch intent.
   - Detached checksum is used for ZIP release integrity.

## Non-goals

- No database
- No event-store service
- No MCP changes
- No Product Context redesign
- No Graphify change
- No S07–S10 expansion
