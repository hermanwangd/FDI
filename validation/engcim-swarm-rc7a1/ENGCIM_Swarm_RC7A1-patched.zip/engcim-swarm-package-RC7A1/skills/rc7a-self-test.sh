#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT

QS="$ROOT/skills/human-input-resume/templates/question-set.yaml"
DR="$ROOT/skills/human-input-resume/templates/decision-response.yaml"
RE="$ROOT/skills/human-input-resume/templates/mission-resume-event.yaml"
STATE="$TMP/.swarm/missions/M-S04-DEMO/state.json"

python3 "$ROOT/skills/human-input-resume/scripts/rc7a_artifacts.py" validate-question-set "$QS"
python3 "$ROOT/skills/human-input-resume/scripts/rc7a_artifacts.py" validate-decision-response "$DR" "$QS"
python3 "$ROOT/skills/human-input-resume/scripts/rc7a_artifacts.py" validate-resume-event "$RE"

python3 "$ROOT/skills/human-input-resume/scripts/rc7a_state.py" init \
  --state "$STATE" --mission M-S04-DEMO --run RUN-S04-001 \
  --state-ref "file://$STATE" --durability local-test

python3 "$ROOT/skills/human-input-resume/scripts/rc7a_state.py" request-input \
  --state "$STATE" --expected-revision 1 --question-set "$QS"

grep -q '"status": "WAITING_FOR_INPUT"' "$STATE"

# Duplicate QuestionSet is safe NO_OP.
python3 "$ROOT/skills/human-input-resume/scripts/rc7a_state.py" request-input \
  --state "$STATE" --expected-revision 2 --question-set "$QS" | grep -q NO_OP

# Wrong expected revision must fail.
if python3 "$ROOT/skills/human-input-resume/scripts/rc7a_state.py" resume \
  --state "$STATE" --expected-revision 1 --decision-response "$DR" --resume-event "$RE"; then
  echo "FAIL stale resume unexpectedly succeeded"; exit 1
fi

python3 "$ROOT/skills/human-input-resume/scripts/rc7a_state.py" resume \
  --state "$STATE" --expected-revision 2 --decision-response "$DR" --resume-event "$RE"

grep -q '"status": "RUNNING"' "$STATE"

# Duplicate DecisionResponse is safe NO_OP.
python3 "$ROOT/skills/human-input-resume/scripts/rc7a_state.py" resume \
  --state "$STATE" --expected-revision 3 --decision-response "$DR" --resume-event "$RE" | grep -q NO_OP

python3 "$ROOT/skills/human-input-resume/scripts/rc7a_state.py" set-artifact \
  --state "$STATE" --expected-revision 3 --artifact INT-E6B19-PC0 --revision 2 --kind IntentionSpec \
  --derived-from INT-E6B19-PC0@1 DEC-E6B-S04-001

python3 "$ROOT/skills/human-input-resume/scripts/rc7a_state.py" summary --state "$STATE" > "$TMP/summary.json"
grep -q 'DEC-E6B-S04-001' "$TMP/summary.json"
grep -q 'INT-E6B19-PC0@2' "$TMP/summary.json"
grep -q 'swarm.stateRef' "$TMP/summary.json"

python3 "$ROOT/skills/human-input-resume/scripts/rc7a_state.py" snapshot --state "$STATE" --out-dir "$TMP/snapshots" > "$TMP/snapshot.json"
grep -q '"sha256"' "$TMP/snapshot.json"

python3 "$ROOT/skills/human-input-resume/scripts/rc7a_state.py" project-metadata --state "$STATE" > "$TMP/metadata.txt"
grep -q '^swarm.stateRef=' "$TMP/metadata.txt"
grep -q '^swarm.stateRevision=' "$TMP/metadata.txt"
grep -q '^swarm.summaryStatus=' "$TMP/metadata.txt"
if grep -q 'swarm.child' "$TMP/metadata.txt"; then
  echo "FAIL compact metadata projection contains swarm.child"; exit 1
fi


# Intention Spec authorization schema and S05 gate.
python3 "$ROOT/skills/pm-intention/scripts/validate_intention_spec.py" \
  "$ROOT/skills/pm-intention/templates/intention-spec-blocked.yaml"
python3 "$ROOT/skills/pm-intention/scripts/validate_intention_spec.py" \
  "$ROOT/skills/pm-intention/templates/intention-spec.yaml"

if python3 "$ROOT/skills/software-development/scripts/authorization_gate.py" \
  "$ROOT/skills/pm-intention/templates/intention-spec-blocked.yaml"; then
  echo "FAIL blocked Intention Spec unexpectedly passed S05 authorization"; exit 1
fi

python3 "$ROOT/skills/software-development/scripts/authorization_gate.py" \
  "$ROOT/skills/pm-intention/templates/intention-spec.yaml"


echo "PASS RC7-A.1 human input/resume self-test"
