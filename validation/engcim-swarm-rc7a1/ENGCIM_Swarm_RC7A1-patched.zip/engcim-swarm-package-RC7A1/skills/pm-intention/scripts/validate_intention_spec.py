#!/usr/bin/env python3
import sys, pathlib, yaml

REQUIRED = [
    "ref", "revision", "product", "capability", "scenario", "currentContext",
    "intent", "expectedDelta", "constraints", "nonGoals", "acceptanceIntent",
    "openQuestions", "implementationAuthorization", "evidenceRefs"
]

def fail(msg):
    print("FAIL", msg)
    return 1

def main():
    if len(sys.argv) != 2:
        print("usage: validate_intention_spec.py <spec.yaml>", file=sys.stderr)
        return 2
    data = yaml.safe_load(pathlib.Path(sys.argv[1]).read_text(encoding="utf-8")) or {}
    missing = [k for k in REQUIRED if k not in data or (data[k] in (None, "", []) and k not in ("openQuestions","evidenceRefs"))]
    if missing:
        return fail("missing required fields: " + ", ".join(missing))

    if not isinstance(data.get("expectedDelta"), list) or not data["expectedDelta"]:
        return fail("expectedDelta must be non-empty list")

    auth = data.get("implementationAuthorization") or {}
    if "authorized" not in auth:
        return fail("implementationAuthorization.authorized missing")
    if not isinstance(auth.get("basisRefs", []), list):
        return fail("implementationAuthorization.basisRefs must be list")
    if not isinstance(auth.get("blockingQuestionSetRefs", []), list):
        return fail("implementationAuthorization.blockingQuestionSetRefs must be list")

    blocking = [
        q for q in (data.get("openQuestions") or [])
        if isinstance(q, dict) and str(q.get("severity","")).upper()=="BLOCKING" and not q.get("resolved")
    ]

    if blocking and auth.get("authorized") is True:
        return fail("authorized=true while unresolved BLOCKING questions exist")
    if blocking and not auth.get("blockingQuestionSetRefs"):
        return fail("unresolved BLOCKING questions require blockingQuestionSetRefs")
    if auth.get("authorized") is False and not blocking and not auth.get("blockingQuestionSetRefs"):
        return fail("authorized=false requires unresolved blocking question or blockingQuestionSetRefs")
    if auth.get("authorized") is True and not auth.get("basisRefs"):
        return fail("authorized=true requires basisRefs, usually DecisionResponse refs")

    evidence = set(data.get("evidenceRefs") or [])
    for ref in auth.get("basisRefs") or []:
        if ref not in evidence:
            return fail(f"authorization basisRef not present in evidenceRefs: {ref}")

    print("PASS intention spec")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
