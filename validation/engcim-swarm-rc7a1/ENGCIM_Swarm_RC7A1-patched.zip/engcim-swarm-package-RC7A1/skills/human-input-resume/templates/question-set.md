# PM Decision Required

Mission: `M-S04-DEMO`  
Source artifact: `INT-E6B19-PC0@1`

Implementation is currently blocked. Please answer the following product decisions in the parent issue comment.

## Q1 — Interaction reduction target

What measurable interaction-reduction target defines success?

Expected format:

```text
Q-interaction-target: 1 primary action
```

## Q2 — 404 retry semantics

Should chart-not-found 404 responses be retryable?

Allowed answers:

```text
Q-retry-404: NON_RETRYABLE_USER_ERROR
```

or

```text
Q-retry-404: RETRYABLE_TRANSIENT_FAILURE
```

## Evidence

- `INT-E6B19-PC0@1`
- `chart-management-spec.md#R-004`
