---
name: human-input-resume
description: Use when a mission cannot proceed without a human product/business decision; produces QuestionSet, consumes DecisionResponse, resumes the same mission, and maintains durable compact MissionExecutionState (RC7-A.1)
---

# Human Input Resume

## Golden rules

1. Do not invent PM decisions.
2. Do not create a replacement Mission to continue after PM answer.
3. Do not store decision truth only in comments.
4. Do not use Multica issue `blocked/done` as the mission-state source of truth.
5. Do not advance S05 while S04 `implementationAuthorization.authorized=false`.
6. Do not write expanded execution truth to Multica metadata. Use durable `MissionExecutionState`.

## Durable state contract

`MissionExecutionState` is the only ENGCIM execution truth.

Multica issue metadata is only a projection:

```text
swarm.stateRef
swarm.stateRevision
swarm.summaryStatus
```

In real Multica runs, `stateRef` must be durable, preferably:

```text
attachment:<attachment-id>
```

where the attachment is an immutable `mission-state-r<N>.json` snapshot. Local file paths are allowed only for package-local self-test and must be marked `durability=local-test`.

## Human comment resume flow

1. Create `QuestionSet.yaml` and `QuestionSet.md`.
2. Post `QuestionSet.md` to the parent issue and attach `QuestionSet.yaml`.
3. Record state as `WAITING_FOR_INPUT`; upload state snapshot and update compact metadata.
4. Human PM answers in a normal parent issue comment.
5. Leader wakes from the human comment.
6. Product Manager / Leader converts the comment into `DecisionResponse.yaml`.
7. Create `MissionResumeEvent.yaml`.
8. Apply `resume` with `--expected-revision`.
9. Upload the new state snapshot and update compact metadata.
10. Resume the same Mission with a new Run.

## Commands

Validate artifacts:

```bash
python3 scripts/rc7a_artifacts.py validate-question-set <question-set.yaml>
python3 scripts/rc7a_artifacts.py validate-decision-response <decision.yaml> <question-set.yaml>
python3 scripts/rc7a_artifacts.py validate-resume-event <resume-event.yaml> <state.json> <decision.yaml>
```

Mutate state with CAS:

```bash
python3 scripts/rc7a_state.py init --state <state.json> --mission <mission> --run <run>
python3 scripts/rc7a_state.py request-input --state <state.json> --expected-revision 1 --question-set <question-set.yaml>
python3 scripts/rc7a_state.py resume --state <state.json> --expected-revision 2 --decision-response <decision.yaml> --resume-event <resume-event.yaml>
```

Create immutable state snapshot:

```bash
python3 scripts/rc7a_state.py snapshot --state <state.json> --out-dir <snapshots-dir>
```

Project compact metadata:

```bash
python3 scripts/rc7a_state.py project-metadata --state <state.json> --state-ref attachment:<id>
```

## Idempotency

- duplicate QuestionSet → `NO_OP`
- duplicate DecisionResponse / ResumeEvent → `NO_OP`
- stale expected revision → `STALE_STATE`
- duplicate artifact revision → `NO_OP`

## Authorization

After resume, S04 must produce a new Intention Spec revision. S05 must run the software-development authorization gate before any repo mutation.
