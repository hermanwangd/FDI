#!/usr/bin/env python3
import sys, pathlib, yaml

def read_yaml(path):
    return yaml.safe_load(pathlib.Path(path).read_text(encoding="utf-8")) or {}

def fail(msg):
    print(f"FAIL {msg}")
    return 1

def validate_question_set(path):
    d = read_yaml(path)
    req = ["questionSetRef","missionRef","sourceArtifactRef","sourceArtifactRevision","requestedRole","blocking","questions"]
    missing = [k for k in req if k not in d]
    if missing:
        return fail("QuestionSet missing fields: " + ", ".join(missing))
    qs = d.get("questions") or []
    if not isinstance(qs, list) or not qs:
        return fail("QuestionSet questions must be non-empty list")
    for q in qs:
        for k in ["id","title","prompt","blocking","answerType"]:
            if k not in q:
                return fail(f"Question missing {k}: {q}")
        if q["answerType"] == "enum" and not q.get("allowedValues"):
            return fail(f"enum question missing allowedValues: {q.get('id')}")
        if q["answerType"] == "integer":
            if q.get("unit") is None:
                return fail(f"integer question missing unit: {q.get('id')}")
    if d.get("blocking") and not any(q.get("blocking") for q in qs):
        return fail("blocking QuestionSet must contain a blocking question")
    print("PASS QuestionSet", d["questionSetRef"])
    return 0

def validate_decision_response(resp_path, qs_path):
    r = read_yaml(resp_path)
    q = read_yaml(qs_path)
    req = ["decisionRef","questionSetRef","missionRef","decidedBy","answers"]
    missing = [k for k in req if k not in r]
    if missing:
        return fail("DecisionResponse missing fields: " + ", ".join(missing))
    if r["questionSetRef"] != q.get("questionSetRef"):
        return fail("DecisionResponse questionSetRef mismatch")
    if r["missionRef"] != q.get("missionRef"):
        return fail("DecisionResponse missionRef mismatch")
    if (r.get("decidedBy") or {}).get("type") != "human":
        return fail("DecisionResponse decidedBy.type must be human")
    answers = {a.get("questionId"): a for a in (r.get("answers") or []) if isinstance(a, dict)}
    for qq in q.get("questions", []):
        if not qq.get("blocking"):
            continue
        aid = qq["id"]
        if aid not in answers:
            return fail("DecisionResponse missing blocking answer: " + aid)
        ans = answers[aid]
        if qq["answerType"] == "enum" and ans.get("value") not in qq.get("allowedValues", []):
            return fail(f"answer {aid} value not allowed: {ans.get('value')}")
        if qq["answerType"] == "integer":
            if not isinstance(ans.get("value"), int):
                return fail(f"answer {aid} must be integer")
            constraints = qq.get("constraints") or {}
            if "min" in constraints and ans["value"] < constraints["min"]:
                return fail(f"answer {aid} below min")
            if "max" in constraints and ans["value"] > constraints["max"]:
                return fail(f"answer {aid} above max")
    print("PASS DecisionResponse", r["decisionRef"])
    return 0

def validate_resume_event(path, state_path=None, decision_path=None):
    d = read_yaml(path)
    req = ["eventRef","eventType","missionRef","questionSetRef","decisionRef","resumeFromRunRef","newRunRef","stateRef","stateRevisionBefore","stateRevisionAfter"]
    missing = [k for k in req if k not in d]
    if missing:
        return fail("MissionResumeEvent missing fields: " + ", ".join(missing))
    if d.get("eventType") != "HUMAN_INPUT_RECEIVED":
        return fail("eventType must be HUMAN_INPUT_RECEIVED")
    if int(d["stateRevisionAfter"]) <= int(d["stateRevisionBefore"]):
        return fail("stateRevisionAfter must increase")
    if decision_path:
        dr = read_yaml(decision_path)
        for k in ["missionRef", "questionSetRef", "decisionRef"]:
            if d.get(k) != dr.get(k):
                return fail(f"ResumeEvent {k} mismatch DecisionResponse")
    if state_path:
        import json
        state = json.loads(pathlib.Path(state_path).read_text(encoding="utf-8"))
        if d.get("missionRef") != state.get("missionRef"):
            return fail("ResumeEvent missionRef mismatch state")
        if int(d["stateRevisionBefore"]) != int(state.get("stateRevision", -1)):
            return fail("ResumeEvent stateRevisionBefore mismatch current state")
    print("PASS MissionResumeEvent", d["eventRef"])
    return 0

def main(argv):
    if len(argv) < 3:
        print("usage: rc7a_artifacts.py <validate-question-set|validate-decision-response|validate-resume-event> ...", file=sys.stderr)
        return 2
    cmd = argv[1]
    if cmd == "validate-question-set":
        return validate_question_set(argv[2])
    if cmd == "validate-decision-response":
        if len(argv) != 4:
            print("usage: validate-decision-response <decision.yaml> <question-set.yaml>", file=sys.stderr)
            return 2
        return validate_decision_response(argv[2], argv[3])
    if cmd == "validate-resume-event":
        # Optional stricter mode:
        # validate-resume-event <event.yaml> [state.json] [decision.yaml]
        state_path = argv[3] if len(argv) >= 4 else None
        decision_path = argv[4] if len(argv) >= 5 else None
        return validate_resume_event(argv[2], state_path, decision_path)
    print("unknown command", cmd, file=sys.stderr)
    return 2

if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
