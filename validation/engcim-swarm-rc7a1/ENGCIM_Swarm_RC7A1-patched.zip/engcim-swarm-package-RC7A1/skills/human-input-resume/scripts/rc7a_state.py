#!/usr/bin/env python3
import argparse, json, pathlib, time, yaml, hashlib, shutil

def load_json(path):
    return json.loads(pathlib.Path(path).read_text(encoding="utf-8"))

def save_json(path, data):
    p = pathlib.Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

def read_yaml(path):
    return yaml.safe_load(pathlib.Path(path).read_text(encoding="utf-8")) or {}

def now_ts():
    return int(time.time())

def require_expected(state, expected):
    if expected is None:
        raise SystemExit("FAIL expectedRevision required for state mutation")
    cur = int(state.get("stateRevision", -1))
    if int(expected) != cur:
        raise SystemExit(f"STALE_STATE expected={expected} current={cur}")

def add_event(state, event_type, ref, extra=None, advance=True):
    if advance:
        state["stateRevision"] = int(state.get("stateRevision", 0)) + 1
    e = {"eventRef": ref, "eventType": event_type, "stateRevision": state["stateRevision"], "ts": now_ts()}
    if extra:
        e.update(extra)
    state.setdefault("events", []).append(e)

def event_exists(state, ref):
    return any(e.get("eventRef") == ref for e in state.get("events", []))

def set_projection(state, summary=None, state_ref=None, durability=None):
    if summary is not None:
        state["summaryStatus"] = summary
    if state_ref is not None:
        state["stateRef"] = state_ref
    if durability is not None:
        state["durability"] = durability

def cmd_init(args):
    state = {
        "missionRef": args.mission,
        "stateRevision": 1,
        "status": "RUNNING",
        "summaryStatus": "RUNNING",
        "stateRef": args.state_ref or f"file://{args.state}",
        "durability": args.durability,
        "currentRunRef": args.run,
        "pendingInputs": [],
        "decisions": [],
        "artifacts": [],
        "children": [],
        "reviews": [],
        "verifications": [],
        "events": [{"eventRef": "EVT-INIT", "eventType": "MISSION_STARTED", "stateRevision": 1, "ts": now_ts()}]
    }
    save_json(args.state, state)
    print("PASS init", args.state)

def cmd_request(args):
    state = load_json(args.state)
    require_expected(state, args.expected_revision)
    qs = read_yaml(args.question_set)
    if state.get("missionRef") != qs.get("missionRef"):
        raise SystemExit("FAIL QuestionSet missionRef mismatch state")
    existing = next((p for p in state.get("pendingInputs", []) if p.get("questionSetRef") == qs["questionSetRef"]), None)
    if existing:
        print(f"NO_OP QuestionSet already present {qs['questionSetRef']} status={existing.get('status')}")
        return
    state["status"] = "WAITING_FOR_INPUT"
    set_projection(state, "WAITING_FOR_INPUT")
    state.setdefault("pendingInputs", []).append({
        "questionSetRef": qs["questionSetRef"],
        "sourceArtifactRef": qs["sourceArtifactRef"],
        "sourceArtifactRevision": qs["sourceArtifactRevision"],
        "blocking": bool(qs.get("blocking")),
        "status": "PENDING"
    })
    add_event(state, "HUMAN_INPUT_REQUESTED", f"EVT-{qs['questionSetRef']}", {"questionSetRef": qs["questionSetRef"]})
    save_json(args.state, state)
    print("PASS waiting_for_input", qs["questionSetRef"], "revision", state["stateRevision"])

def cmd_resume(args):
    state = load_json(args.state)
    require_expected(state, args.expected_revision)
    dr = read_yaml(args.decision_response)
    ev = read_yaml(args.resume_event)
    if state.get("missionRef") != dr.get("missionRef"):
        raise SystemExit("FAIL DecisionResponse missionRef mismatch state")
    for k in ["missionRef", "questionSetRef", "decisionRef"]:
        if ev.get(k) != dr.get(k):
            raise SystemExit(f"FAIL ResumeEvent {k} mismatch DecisionResponse")
    if event_exists(state, ev["eventRef"]) or any(d.get("decisionRef") == dr["decisionRef"] for d in state.get("decisions", [])):
        print(f"NO_OP DecisionResponse already consumed {dr['decisionRef']}")
        return
    matched = False
    for p in state.get("pendingInputs", []):
        if p.get("questionSetRef") == dr.get("questionSetRef"):
            matched = True
            if p.get("status") == "ANSWERED":
                print(f"NO_OP QuestionSet already answered {p.get('questionSetRef')}")
                return
            p["status"] = "ANSWERED"
            p["decisionRef"] = dr["decisionRef"]
    if not matched:
        raise SystemExit("FAIL questionSetRef not pending")
    state.setdefault("decisions", []).append({
        "decisionRef": dr["decisionRef"],
        "questionSetRef": dr["questionSetRef"],
        "answers": dr.get("answers", []),
        "decidedBy": dr.get("decidedBy"),
        "sourceCommentRef": dr.get("sourceCommentRef")
    })
    state["status"] = "RUNNING"
    set_projection(state, "RUNNING")
    state["currentRunRef"] = ev.get("newRunRef")
    add_event(state, "HUMAN_INPUT_RECEIVED", ev["eventRef"], {"decisionRef": dr["decisionRef"], "questionSetRef": dr["questionSetRef"]})
    save_json(args.state, state)
    print("PASS resumed", dr["decisionRef"], "revision", state["stateRevision"])

def cmd_set_artifact(args):
    state = load_json(args.state)
    require_expected(state, args.expected_revision)
    existing = next((a for a in state.get("artifacts", []) if a.get("artifactRef") == args.artifact and int(a.get("revision", -1)) == int(args.revision)), None)
    if existing:
        print(f"NO_OP artifact already recorded {args.artifact}@{args.revision}")
        return
    state.setdefault("artifacts", []).append({
        "artifactRef": args.artifact,
        "revision": int(args.revision),
        "kind": args.kind,
        "status": args.status,
        "derivedFrom": args.derived_from or []
    })
    add_event(state, "ARTIFACT_REVISED", f"EVT-{args.artifact}-{args.revision}", {"artifactRef": args.artifact, "revision": int(args.revision)})
    save_json(args.state, state)
    print("PASS artifact", args.artifact, args.revision, "revision", state["stateRevision"])

def cmd_record_child(args):
    state = load_json(args.state)
    require_expected(state, args.expected_revision)
    children = state.setdefault("children", [])
    cur = next((c for c in children if c.get("childRef") == args.child), None)
    if cur is None:
        cur = {"childRef": args.child, "requirement": args.requirement}
        children.append(cur)
    cur["dispatchStatus"] = args.dispatch_status
    cur["executionOutcome"] = args.execution_outcome
    cur["artifactRevision"] = int(args.artifact_revision)
    add_event(state, "CHILD_STATE_RECORDED", f"EVT-CHILD-{args.child}-{state.get('stateRevision',0)+1}", {"childRef": args.child})
    save_json(args.state, state)
    print("PASS child", args.child, "revision", state["stateRevision"])

def cmd_record_review(args):
    state = load_json(args.state)
    require_expected(state, args.expected_revision)
    ref = f"{args.artifact}@{args.revision}:{args.verdict}"
    if any(r.get("reviewRef") == args.review_ref for r in state.get("reviews", [])):
        print(f"NO_OP review already recorded {args.review_ref}")
        return
    state.setdefault("reviews", []).append({
        "reviewRef": args.review_ref,
        "artifactRef": args.artifact,
        "artifactRevision": int(args.revision),
        "verdict": args.verdict
    })
    add_event(state, "REVIEW_RECORDED", f"EVT-REVIEW-{args.review_ref}", {"artifactRef": args.artifact, "artifactRevision": int(args.revision)})
    save_json(args.state, state)
    print("PASS review", args.review_ref, "revision", state["stateRevision"])

def cmd_record_verification(args):
    state = load_json(args.state)
    require_expected(state, args.expected_revision)
    if any(v.get("verificationRef") == args.verification_ref for v in state.get("verifications", [])):
        print(f"NO_OP verification already recorded {args.verification_ref}")
        return
    state.setdefault("verifications", []).append({
        "verificationRef": args.verification_ref,
        "artifactRef": args.artifact,
        "artifactRevision": int(args.revision),
        "verdict": args.verdict
    })
    add_event(state, "VERIFICATION_RECORDED", f"EVT-VERIFY-{args.verification_ref}", {"artifactRef": args.artifact, "artifactRevision": int(args.revision)})
    save_json(args.state, state)
    print("PASS verification", args.verification_ref, "revision", state["stateRevision"])

def cmd_snapshot(args):
    state = load_json(args.state)
    out_dir = pathlib.Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    rev = int(state.get("stateRevision", 0))
    mission = state.get("missionRef", "mission")
    out = out_dir / f"{mission}-state-r{rev}.json"
    save_json(out, state)
    sha = hashlib.sha256(out.read_bytes()).hexdigest()
    manifest = {"stateFile": str(out), "missionRef": mission, "stateRevision": rev, "sha256": sha}
    manifest_path = out.with_suffix(".manifest.json")
    save_json(manifest_path, manifest)
    print(json.dumps(manifest, indent=2))

def cmd_project_metadata(args):
    state = load_json(args.state)
    state_ref = args.state_ref or state.get("stateRef")
    print(f"swarm.stateRef={state_ref}")
    print(f"swarm.stateRevision={state.get('stateRevision')}")
    print(f"swarm.summaryStatus={state.get('summaryStatus')}")

def cmd_summary(args):
    state = load_json(args.state)
    print(json.dumps({
        "missionRef": state.get("missionRef"),
        "status": state.get("status"),
        "summaryStatus": state.get("summaryStatus"),
        "stateRevision": state.get("stateRevision"),
        "stateRef": state.get("stateRef"),
        "durability": state.get("durability"),
        "pendingInputs": state.get("pendingInputs", []),
        "decisions": [d.get("decisionRef") for d in state.get("decisions", [])],
        "artifacts": [f"{a.get('artifactRef')}@{a.get('revision')}" for a in state.get("artifacts", [])],
        "children": [c.get("childRef") for c in state.get("children", [])],
        "reviews": [r.get("reviewRef") for r in state.get("reviews", [])],
        "verifications": [v.get("verificationRef") for v in state.get("verifications", [])],
        "metadataProjection": {
            "swarm.stateRef": state.get("stateRef"),
            "swarm.stateRevision": state.get("stateRevision"),
            "swarm.summaryStatus": state.get("summaryStatus")
        }
    }, indent=2, ensure_ascii=False))

def main():
    p = argparse.ArgumentParser()
    sub = p.add_subparsers(dest="cmd", required=True)

    s = sub.add_parser("init")
    s.add_argument("--state", required=True)
    s.add_argument("--mission", required=True)
    s.add_argument("--run", required=True)
    s.add_argument("--state-ref")
    s.add_argument("--durability", default="local-test")
    s.set_defaults(fn=cmd_init)

    s = sub.add_parser("request-input")
    s.add_argument("--state", required=True)
    s.add_argument("--expected-revision", required=True, type=int)
    s.add_argument("--question-set", required=True)
    s.set_defaults(fn=cmd_request)

    s = sub.add_parser("resume")
    s.add_argument("--state", required=True)
    s.add_argument("--expected-revision", required=True, type=int)
    s.add_argument("--decision-response", required=True)
    s.add_argument("--resume-event", required=True)
    s.set_defaults(fn=cmd_resume)

    s = sub.add_parser("set-artifact")
    s.add_argument("--state", required=True)
    s.add_argument("--expected-revision", required=True, type=int)
    s.add_argument("--artifact", required=True)
    s.add_argument("--revision", required=True)
    s.add_argument("--kind", required=True)
    s.add_argument("--status", default="CURRENT")
    s.add_argument("--derived-from", nargs="*", default=[])
    s.set_defaults(fn=cmd_set_artifact)

    s = sub.add_parser("record-child")
    s.add_argument("--state", required=True)
    s.add_argument("--expected-revision", required=True, type=int)
    s.add_argument("--child", required=True)
    s.add_argument("--requirement", default="REQUIRED")
    s.add_argument("--dispatch-status", required=True)
    s.add_argument("--execution-outcome", required=True)
    s.add_argument("--artifact-revision", required=True)
    s.set_defaults(fn=cmd_record_child)

    s = sub.add_parser("record-review")
    s.add_argument("--state", required=True)
    s.add_argument("--expected-revision", required=True, type=int)
    s.add_argument("--review-ref", required=True)
    s.add_argument("--artifact", required=True)
    s.add_argument("--revision", required=True)
    s.add_argument("--verdict", required=True)
    s.set_defaults(fn=cmd_record_review)

    s = sub.add_parser("record-verification")
    s.add_argument("--state", required=True)
    s.add_argument("--expected-revision", required=True, type=int)
    s.add_argument("--verification-ref", required=True)
    s.add_argument("--artifact", required=True)
    s.add_argument("--revision", required=True)
    s.add_argument("--verdict", required=True)
    s.set_defaults(fn=cmd_record_verification)

    s = sub.add_parser("snapshot")
    s.add_argument("--state", required=True)
    s.add_argument("--out-dir", required=True)
    s.set_defaults(fn=cmd_snapshot)

    s = sub.add_parser("project-metadata")
    s.add_argument("--state", required=True)
    s.add_argument("--state-ref")
    s.set_defaults(fn=cmd_project_metadata)

    s = sub.add_parser("summary")
    s.add_argument("--state", required=True)
    s.set_defaults(fn=cmd_summary)

    args = p.parse_args()
    args.fn(args)

if __name__ == "__main__":
    main()
