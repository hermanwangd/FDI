#!/usr/bin/env python3
import sys, pathlib, yaml

def fail(msg):
    print("FAIL", msg)
    return 1

def main():
    if len(sys.argv) != 2:
        print("usage: authorization_gate.py <intention-spec.yaml>", file=sys.stderr)
        return 2
    data = yaml.safe_load(pathlib.Path(sys.argv[1]).read_text(encoding="utf-8")) or {}
    auth = data.get("implementationAuthorization")
    if not isinstance(auth, dict):
        return fail("implementationAuthorization missing")
    if auth.get("authorized") is not True:
        return fail("implementationAuthorization.authorized is not true")
    if not auth.get("basisRefs"):
        return fail("authorized implementation requires basisRefs")
    blocking = [
        q for q in (data.get("openQuestions") or [])
        if isinstance(q, dict) and str(q.get("severity","")).upper()=="BLOCKING" and not q.get("resolved")
    ]
    if blocking:
        return fail("unresolved BLOCKING questions remain")
    print("PASS implementation authorization")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
