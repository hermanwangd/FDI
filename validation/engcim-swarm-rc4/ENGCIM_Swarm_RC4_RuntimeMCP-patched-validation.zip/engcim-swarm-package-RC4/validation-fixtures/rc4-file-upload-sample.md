# RC4 file-ingestion smoke fixture

This is a harmless synthetic product note for the ENGCIM Swarm RC4 validation.

- Product name: RC4 Synthetic Catalog
- Capability: deterministic catalog lookup
- Boundary: this fixture is test-only and must not be treated as production truth
- Owner: validation-fixture
- Version: fixture-1

The ingestion result must preserve the source filename, source class, document
identity, retrieval timestamp, and provisional validation state. Do not invent
external evidence and do not include secrets.
