# ENGCIM Swarm RC4 real-runtime validation mission

This is a controlled validation mission for the newly created Multica workspace.
It is not a product implementation task.

## Safety and scope

- Do not modify the existing `Herman_Lab` workspace, the FDI repository, or any
  existing repository or external system.
- Do not create PRs, commits, releases, cloud resources, or real work-item
  changes.
- Use only the attached synthetic fixture and the package's local self-tests.
- The attached `validation-fixtures/rc4-file-upload-sample.md` is the file-upload
  smoke input. `rc4-repository-manifest.yaml` is scope-only; do not clone or
  contact its example URL.
- If a capability is unavailable, record the exact command/tool/run evidence as
  BLOCKED or NOT VERIFIED. Never infer PASS from a successful issue/comment API
  call and never guess MCP tool names.

## Required validation work

The Orchestrator must write a concise SPEC, create at least three independent
children, record dispatch metadata, and verify real run evidence. Use required
children for the following independent work:

1. Runtime-native capability probe: attempt the package's TKMS and Azure DevOps
   ingestion paths using the current runtime-native/auto preference. Read-only
   only. Report the exact capability/tool discovery result; do not use managed
   fallback and do not fabricate source data.
2. File-ingestion smoke: process the attached synthetic Markdown file through
   `pk-file-ingestion` / document analysis / correlation rules. Preserve
   provenance, create only test-workspace governance artifacts if the normal
   flow requires them, and validate the resulting local structured store. Do not
   promote the fixture to trusted production knowledge.
3. Independent verifier: inspect the first two children and rerun the package's
   deterministic Graphify and PK schema checks. Verify evidence shape, source
   classification, provisional state, and safety boundaries without changing
   external systems.

The first file-ingestion draft should intentionally identify one missing or
ambiguous provenance field as an explicit finding, so the reviewer can exercise
one genuine REVISE -> revision + 1 -> re-review path. The worker must then fix
that field using only fixture facts. If the platform cannot exercise this path,
report it as NOT VERIFIED instead of claiming it.

## Completion contract

The parent must remain `in_review`, not `done`. The final aggregation must list
each child, run IDs/ack evidence, result, review status and revision, verification
status, conflicts, and unresolved blockers. If the runtime-native TKMS/Azure
capabilities are absent, the final report must say so explicitly and keep those
checks blocked.
