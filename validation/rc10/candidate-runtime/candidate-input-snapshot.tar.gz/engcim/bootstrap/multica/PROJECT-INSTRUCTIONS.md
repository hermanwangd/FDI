# Multica Project Instructions

Read `docs/overview/FDI-PROJECT-OVERVIEW.md` first, then `governance/CURRENT`, `governance/locks/approved-source-lock.json`, `docs/planning/STATUS.json`, `docs/planning/DEVELOPMENT-BACKLOG.md`, and only then detailed specifications/contracts/Skills.

Never infer governing semantics from a module ID alone. Every active module ID MUST resolve to a local file/directory in the approved-source lock and pass digest verification.

Multica owns execution choices (agents/models/parallelism/retries/escalation/cost observability) but must not redefine T1–T4, HERM-211 helper identities, canonical gates, Product Asset publication authority, current-evidence rules, or T4 independence.

For the isolated RC10 candidate, resolve the versioned Workspace Learning
addendum through `engcim/bootstrap/multica/MAPPING.md`. Its source is candidate
procedure content, not approved governing semantics. Load full bytes into the
two existing role instruction fields with a revision/digest envelope; a file
path mentioned in an issue does not constitute loading. Preserve original
instructions and do not edit sealed RC6 assets. A fresh run must report the
effective envelope and demonstrate its applicable behavior. Locally the
Supervisor front end is Codex CLI; company operation uses Claude CLI.
