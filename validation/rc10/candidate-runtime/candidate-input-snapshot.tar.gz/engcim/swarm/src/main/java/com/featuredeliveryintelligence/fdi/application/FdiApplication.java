package com.featuredeliveryintelligence.fdi.application;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages = "com.featuredeliveryintelligence.fdi")
public class FdiApplication {
    public static void main(String[] args) {
        if (Dev204Cli.handles(args)) return;
        SpringApplication.run(FdiApplication.class, args);
    }
}
