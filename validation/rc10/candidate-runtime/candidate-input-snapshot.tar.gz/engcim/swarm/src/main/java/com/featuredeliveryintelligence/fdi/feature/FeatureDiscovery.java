package com.featuredeliveryintelligence.fdi.feature;
import com.featuredeliveryintelligence.fdi.shared.*;
import java.util.*;
public final class FeatureDiscovery {
 private FeatureDiscovery() {}
 public static Map<String,Object> groundStructuralHints(Map<String,Object> hints,List<Map<String,Object>> inventory,List<String> scope,int max){
  if(!Boolean.TRUE.equals(hints.get("non_authoritative"))||scope.isEmpty()||max<1)throw new RuntimeContractException("invalid structural discovery request");
  Map<String,Map<String,Object>> by=new HashMap<>(); for(var x:inventory){String id=RuntimeMaps.requiredString(x,"repository_id");if(by.put(id,x)!=null)throw new RuntimeContractException("duplicate PA-03 repository identity: "+id);}
  Map<String,Set<String>> obs=new TreeMap<>(); for(Object o:RuntimeMaps.list(hints,"hints")){var h=asMap(o);if(!Boolean.TRUE.equals(h.get("non_authoritative")))throw new RuntimeContractException("every structural hint must be non_authoritative");obs.computeIfAbsent(RuntimeMaps.requiredString(h,"repository_id"),k->new TreeSet<>()).addAll(strings(RuntimeMaps.list(h,"observation_ids")));}
  List<Map<String,Object>> out=new ArrayList<>(),diag=new ArrayList<>(); for(var e:obs.entrySet()){var a=by.get(e.getKey());if(a==null||!scope.contains(a.get("product_scope"))||!"PUBLISHED".equals(a.get("publication_state"))||!"ACTIVE".equals(a.get("validity_state"))){diag.add(Map.of("code","INELIGIBLE_PA03","repository_id",e.getKey()));continue;}out.add(Map.of("repository_id",e.getKey(),"basis","LAYER2_PA03","pa03_asset_ref_id",RuntimeMaps.requiredString(a,"pa03_asset_ref_id"),"structural_observation_ids",List.copyOf(e.getValue()),"candidate_only",true));}
  boolean truncated=out.size()>max;if(truncated)out=new ArrayList<>(out.subList(0,max));return new LinkedHashMap<>(Map.of("candidate_augmentations",out,"diagnostics",diag,"incomplete",truncated||!diag.isEmpty(),"truncated",truncated));
 }
 @SuppressWarnings("unchecked")private static Map<String,Object>asMap(Object v){if(!(v instanceof Map<?,?>))throw new RuntimeContractException("item must be object");return(Map<String,Object>)v;} private static Set<String>strings(List<Object>v){Set<String>s=new TreeSet<>();for(Object x:v)s.add(String.valueOf(x));return s;}
}
