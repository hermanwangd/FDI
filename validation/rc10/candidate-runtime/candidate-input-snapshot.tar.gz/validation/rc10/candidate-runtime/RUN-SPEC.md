# RC10 local candidate validation specification

Candidate: `RC10-local-candidate-20260926-01`. Status: PREPARED, not runtime PASS.
Source identity is the adjacent `candidate-input-manifest.json` and its digest;
Git HEAD alone does not identify this dirty candidate. Package resealing follows
evidence collection; the previous candidate ZIP is not this snapshot.

## Scope and execution profile

- Supervisor: local Codex CLI. Existing Swarm runtime: Kimi
  `4f0a8b0c-3ee8-4481-a40c-2fb8aadbb39d`, model
  `kimi-code/kimi-for-coding`; retain existing assignment/runtime settings.
- Workspace: `0b02adb6-a395-46bd-bd92-6fec14dee20e` only.
- Validation project: `a3f129fa-4028-4341-98dc-c8ec20c468ae`.
- ProductKB: `f7af4546-88b2-4163-a0d4-b350e2123dbc`.
- WorkspaceKnowledge: `43aec4ec-3ebb-4d1b-aa54-7766c48379c1`.
- Existing Swarm squad: `ba1c9f0d-00fd-48a3-8865-dfbc4ff35f73`;
  Orchestrator `809ffefe-3fc4-4686-8401-a8dd50285840`,
  Curator `c38a925f-171b-4c24-91c2-68329ae42654`,
  Reviewer `53a77a8b-aec9-4d7b-821e-0dae15e48c0c`,
  Verifier `043dc4fa-412c-46cc-a27b-bc302d584e97`.
- Permitted writes: two role instruction fields with backup/readback/rollback;
  new scoped validation issues, comments, evidence and WorkspaceKnowledge
  records; ProductKB candidate ingestion/refresh preserving prior history;
  disposable fixture candidate source/output. No FDI authority or production
  mutation, no company Claude execution, no direct Swarm tKMS access.
- Resource budget: one parent Scenario at a time; at most two concurrent Swarm
  runs; max eight required children, two correction revisions per Scenario,
  forty-five minutes per Scenario and twenty minutes per child. Stop dispatch
  and inspect actual active runs on exceeding a bound. Total task process RSS
  must remain below 8 GiB. No automatic retry after an uncertain dispatch.
- Existing independently completed baseline records remain intact. Agents leave
  final Missions `in_review`; Human DONE is not simulated.

## Input fixtures and governing assertions

Use the current canonical RC6 runtime's Scenario/Skill procedures. The local
sealed baseline and installed archive identities are recorded separately in
`../rc6-baseline-2026-09-26/BASELINE-RECORD.md` and must not be conflated.
The supplemental S01–S06 contract remains draft; the following assertions are
the authorized validation plan's acceptance, not promotion of that draft.

Chart Viewer fixture resource `7758135b-d13e-4440-aa26-4b0003c14967` is pinned to
`2eff5f9f84ca709684bfe0b7c90102268f07a0f0`. RC7-B negative-control resource
`0aaa038b-25ff-4c9e-958d-fece38e2de3b` is pinned to
`92ec2570a4da188baca4bbb50f48db27e6906c89`. Resolve their project resources and
verify Git objects before analysis; attachment/README filenames alone do not
prove source revision. No cross-repository dependency is currently evidenced.

| Stage | Input and required result |
|---|---|
| S01 | Pinned Chart Viewer product sources (same five original attachments from baseline RC10VAL-4), complementary sources and a duplicate. Fresh candidate-role execution must produce traced observations, deduplication, valid structured PK and governance links. Preserve seeded contradictions as conflicts; attach exact store snapshot and independent review/verification. |
| S02 | S01 store plus a separately versioned synthetic document update, including a stale claim and conflict. Demonstrate explicit delta, history/supersession, conflict disposition and repeat-read/replay behavior. Bind every change to its new source digest. |
| S03 | Both pinned fixture repositories and current PK. Inspect actual code before reporting relations; an independent/no-supported-edge result is valid. Require graph provenance for both exact revisions, no invented dependency. |
| S04 | Bounded request: open the selected Chart Viewer chart in one interaction while preserving non-retryable HTTP 404. Use actual S02/S03 context; deliver IntentSpec with scope, acceptance and evidence refs. Adopt the fixture's explicit fault-test sequence: initial S05 r1 may change only `src/interaction.js`; frozen chart limit remains 10 but the seeded implementation defect is deliberately outside r1 mutation scope. |
| S05 | S04 IntentSpec and disposable pinned Chart Viewer. Deliver design/spec, minimal r1 interaction diff, exact candidate source digest/ref and test receipts. Preserve `src/chartViewer.js` in r1. Do not repair FDI framework or production repositories. |
| S06 | Verify exact S05 r1 independently, including frozen max=10 and HTTP 404 regression. The seeded max=1000 must produce Finding F1 and a non-PASS r1 result. A revision-bound Control decision may expand only the disposable fixture correction scope to `src/chartViewer.js`; return to S05 for r2, then independently rerun failed and affected tests. Final PASS requires r2 evidence and retained r1 failure/F1/scope-decision history. |

A stage dispatch requires evidence that its prerequisite delivery/review/
verification gates are satisfied. Issue status or producer prose is insufficient.
When a stage ends, persist issue/run/comment/attachment references and copy the
actual deliverable bytes needed by the next stage. No inferred PASS.

## Learning / reuse validation

After an independently verified Mission result, Codex Supervisor produces a
schema-shaped MissionLearningSource containing that result's real references.
The existing Orchestrator composes Curator processing and existing independent
Reviewer/Verifier runs. For this isolated test, Orchestrator may issue an
explicit workspace-guidance decision after those runs verify attribution,
workspace/project scope, source/evidence, conflict disposition and applicability.
This delegation covers only synthetic workspace guidance in this workspace,
not product truth, Skill/Control/Core changes or Human Mission DONE.

The decision binds the proposal digest/key/version and actual evidence, not
the expected test outcome. Unknown authority/evidence yields DEFERRED; failed
scope or unresolved conflict cannot yield APPROVED. Curator persists using
the installed addendum. Supervisor reads the returned receipt to verify it,
without writing the knowledge record itself.

A separate subsequent Mission must perform fresh scoped provider retrieval and
show the selected Authorized Visible Context in its actual worker input/result.
Also test DEFERRED, REJECTED, expired, wrong workspace/project, conflicting and
duplicate candidates. Foreign-scope cases use synthetic invalid envelopes in
this workspace; no foreign workspace writes. Verify repeated identical capture
does not silently duplicate; simulate an uncertain acknowledgement by reconciling
an already written record, clearly labeled as a controlled simulation rather
than an observed transport timeout. Preserve excluded-record reasons.

## Checkpoints and rollback

1. Backup exact live role instructions and confirm no active runs on either role.
2. Deploy the two prepared texts; verify exact readback and unchanged Skills,
   models, runtime assignments and invocation permissions. On partial failure,
   reconcile/restore changed fields before dispatch.
3. Obtain the effective envelope in a real candidate run plus applicable behavior.
   Missing load identity or failed scope blocks dependent dispatch.
4. Observe actual run handles; a polling timeout does not establish termination.
5. Retain all failures/corrections and revision boundaries. Restore only these
   role fields if candidate rollback is necessary, preserving all evidence.
6. Reseal reports/package against this snapshot and evidence cutoff only after
   final outcomes are known. Phase 1 formal handoff is separate from a progress
   snapshot; notify the requesting Phase 2 task only at formal handoff.
